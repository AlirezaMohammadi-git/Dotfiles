wal -q -i ~/wallpaper/ 

exit
