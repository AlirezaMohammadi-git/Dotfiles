yay -Scc
su -c 'pacman -Qtdq | pacman -Rns -'
su -c 'pacman -Qqd | pacman -Rsu -'

